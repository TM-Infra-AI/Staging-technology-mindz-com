<?php
/**
 * Ekko functions file
 *
 * @package ekko
 * by KeyDesign
 */

 add_action( 'wp_enqueue_scripts', 'kd_enqueue_parent_theme_style', 5 );
 if ( ! function_exists( 'kd_enqueue_parent_theme_style' ) ) {
     function kd_enqueue_parent_theme_style() {
         wp_enqueue_style( 'bootstrap' );
		 wp_enqueue_script ( 'dropdown-filter', get_template_directory_uri() . '/ajax/dropdown-filter.js','', false );
		 wp_enqueue_style( 'keydesign-style', get_template_directory_uri() . '/style.css', array( 'bootstrap' ) );
         wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array('keydesign-style') );
     }
 }

 add_action( 'after_setup_theme', 'kd_child_theme_setup' );
 if ( ! function_exists( 'kd_child_theme_setup' ) ) {
     function kd_child_theme_setup() {
         load_child_theme_textdomain( 'ekko', get_stylesheet_directory() . '/languages' );
     }
 }




 //add_action('wp_ajax_my_api_request', 'my_api_request_callback');
 //add_action('wp_ajax_nopriv_my_api_request', 'my_api_request_callback');


 // -------------------------------------
 // Edit below this line
 // -------------------------------------

 function wpcodex_add_excerpt_support_for_post() {
    add_post_type_support( 'portfolio_ss', 'excerpt' );
}
add_action( 'init', 'wpcodex_add_excerpt_support_for_post' );



// =========================================================================
// MULTIPLE DROPDOWN FILTER SHORTCODE 
// =========================================================================
function multiple_dropdown_filter_shortcodee(){
    ob_start();
        include('ajax/dropdown-filter.php');
    return ob_get_clean();
}
add_shortcode('multiple-dropdown-filter', 'multiple_dropdown_filter_shortcodee');


 //javscript addd
 function wpflameses_multiple_filter_function(){
	$args = array(
		'orderby' => 'date', // we will sort posts by date
		'order'	=> $_POST['date'] // ASC or DESC
	);
 
	// for taxonomies / categories
// 	if( isset($_POST['categoryfilter']) && isset($_POST['taxonomyfilter'] )  && isset($_POST['product'] ))
// 		$args['tax_query'] = array(
// 			'relation' => 'OR',
//             // 'relation' => 'AND',
// 			array(
// 				'taxonomy' => 'category',
// 				'field' => 'id',
// 				'terms' => $_POST['categoryfilter']
// 			),
// // 			array(
// // 				'taxonomy' => 'service',
// // 				'field' => 'id',
// // 				'terms' => $_POST['taxonomyfilter']
// // 			),
// 			array(
// 				'taxonomy' => 'product',
// 				'field' => 'id',
// 				'terms' => $_POST['product']
// 			)
// 		);

    if( !empty($_POST['categoryfilter']) && !empty($_POST['taxonomyfilter'] )  && !empty($_POST['product'] )){
		$args['tax_query'] = array(
            'relation' => 'AND',
			array(
				'taxonomy' => 'category',
				'field' => 'id',
				'terms' => $_POST['categoryfilter']
			),
			array(
				'taxonomy' => 'product',
				'field' => 'id',
				'terms' => $_POST['product']
			)
		);
    }else if( !empty($_POST['categoryfilter']) && empty($_POST['taxonomyfilter']) && empty($_POST['product'])){
        
        $args = array(
            'post_type' => 'portfolio_ss',
            'posts_per_page' => -1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'category',
                    'field' => 'id',
                    'terms' => $_POST['categoryfilter']
                )
        
            )
        );
        
	}else if( !empty($_POST['categoryfilter']) || !empty($_POST['taxonomyfilter'] )  && empty($_POST['product'] )){
    // }else if( !empty($_POST['categoryfilter']) || !empty($_POST['taxonomyfilter'] )){
		$args['tax_query'] = array(
            'relation' => 'AND',
			array(
				'taxonomy' => 'category',
				'field' => 'id',
				'terms' => $_POST['categoryfilter']
			),
			array(
				'taxonomy' => 'service',
				'field' => 'id',
				'terms' => $_POST['taxonomyfilter']
			)
		);
    } else if( !empty($_POST['taxonomyfilter'] ) && !empty($_POST['product'] )){
		$args['tax_query'] = array(
            'relation' => 'AND',
			array(
				'taxonomy' => 'service',
				'field' => 'id',
				'terms' => $_POST['taxonomyfilter']
			),
			array(
				'taxonomy' => 'product',
				'field' => 'id',
				'terms' => $_POST['product']
			)
		);
    }else if( empty($_POST['categoryfilter']) && empty($_POST['taxonomyfilter']) && empty($_POST['product'])){
        $args = array(
            'post_type' => 'portfolio_ss',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby'     => 'modified',
            'order'       => 'DESC',
        );
    }
	
 
	$query = new WP_Query( $args );
 
	if( $query->have_posts() ) : ?>
	     <div class="row"><?php 
		while( $query->have_posts() ): $query->the_post();
		
		
		echo '<div class="col-lg-6 listCaseStudy">';

		$id = get_the_post_thumbnail_url( $query->ID );
		echo  "<img src='$id'>";

		 echo '<div class="newCaseStudyContent">';
		 			 	echo '<a href="';
	 	the_permalink();
echo '">';
		echo '<h4>' . $query->post->post_title . '</h4>';
        echo '<p>' . $query->post->post_excerpt . '</p>';
        
         echo '</div>';
    
          echo '</div>';
		endwhile;
		?>  </div> <?php
		wp_reset_postdata();
	else :
		echo 'No posts found';
	endif;
 
	die();
}
add_action('wp_ajax_myfilter_2', 'wpflameses_multiple_filter_function'); 
add_action('wp_ajax_nopriv_myfilter_2', 'wpflameses_multiple_filter_function');








function enqueue_my_script() {
    wp_enqueue_script('my-custom-script', get_stylesheet_directory_uri() . '/custom/custom-script.js', array('jquery'), '1.0', true);
	wp_localize_script('my-custom-script', 'my_ajax_object', array('ajaxcallingurl' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'enqueue_my_script');

/*------------------ Ajax casestudy select box selector on category start ---------------------*/

add_action('wp_ajax_category_ajax_action', 'category_ajax_function');
add_action('wp_ajax_nopriv_category_ajax_action', 'category_ajax_function');
function category_ajax_function() {
    if($_POST['categoryName'] != '' || !empty($_POST['categoryName'])){
        global $wpdb, $table_prefix;
        $category = $_POST['categoryName'];
    	$service = "";
    	
    	if($category == 'Retail' || $category == 'Retail Business'){
    	    $service = "name IN ('Web Development', 'Salesforce')";
    	}elseif($category == 'E-Commerce'){
    		$service = "name IN ('Web Development', 'Salesforce')";
    	}elseif($category == 'Financial Services'){
    		$service = "name IN ('IT Helpdesk', 'Salesforce')";
    	}elseif($category == 'Truck Transportation Business'){
    	    $service = "name IN ('Cybersecurity', 'Salesforce')";
    	}elseif($category == 'Financial'){
    	    $service = "name IN ('IT Helpdesk')";
    	}elseif($category == 'Advertising Services' || $category == 'Architecture' || $category == 'Construction Industry' || $category == 'Information technology and services'){
    		$service = "name IN ('Salesforce')";
    	}elseif($category == 'Automobile' || $category == 'Information Technology & Services' || $category == 'Banking' || $category == 'Building And Construction' || $category == 'Business Consulting And Services' || $category == 'Education'){
    		$service = "name IN ('Salesforce')";
    	}elseif($category == 'Electric industry' || $category == 'General' || $category == 'Healthcare' || $category == 'Insurance' || $category == 'IT Services And IT Consulting' || $category == 'Music Industry' || $category == 'Non-Profit'){
    		$service = "name IN ('Salesforce')";
    	}elseif($category == 'Professional Services' || $category == 'Real Estate' || $category == 'Retailer' || 'Software Development' || $category == 'Telecommunications Industry' || $category == 'Translation And Localization' || $category == 'Transportation And Vehicle Rental'){
    		$service = "name IN ('Salesforce')";
    	}
    
        $wp_table = $table_prefix.'terms';
        $sql = "SELECT term_id, name FROM `$wp_table` WHERE ".$service." Group By name";
        $results = $wpdb->get_results($sql);
        echo $response = '<option value="">Select Services...</option>';
        foreach($results as $term){
            echo $response = '<option value="' . $term->term_id . '" data-service="' . $term->name . '">' . $term->name . '</option>';
        }
    }elseif($_POST['categoryName'] == '' || empty($_POST['categoryName'])){
        if( $terms_2 = get_terms( array( 'taxonomy' => 'service', 'orderby' => 'name' ) ) ) : 
            echo $response = '<option value="">Select Services...</option>';
			foreach ( $terms_2 as $term ) :
				echo '<option value="' . $term->term_id . '" data-service="' . $term->name . '">' . $term->name . '</option>';
            endforeach;
		endif;
    }
    
    
    exit();
}

/*------------------ Ajax casestudy select box selector on category end ---------------------*/


/*------------------ Ajax casestudy select box selector on service start ---------------------*/

add_action('wp_ajax_service_ajax_action', 'service_ajax_function');
add_action('wp_ajax_nopriv_service_ajax_action', 'service_ajax_function');
function service_ajax_function() {
    global $wpdb, $table_prefix;
    $service = $_POST['serviceName'];
    $categoryName = $_POST['categoryName'];
	$product = "";
	
// 	if($service == 'Web Development'){
// 		$product = "name IN ('Magento', 'Laravel', 'Shopify', 'Exact CRM')";
// 	}elseif($service == 'IT Helpdesk'){
// 		$product = "name IN ('ServiceDesk', 'Endpoint Central', 'Sophos Central')";
// 	}elseif($service == 'Cybersecurity'){
// 	    $product = "name IN ('Firewall', 'Microsoft Office 365')";
// 	}else
	
	if(($service == 'Salesforce') && ($categoryName == '' || empty($categoryName)) ){
	    $product = "name IN ('Amazon API', 'Sales Cloud', 'Apex Bulk API Integration', 'CallRail', 'CJ Affiliate', 'Constant Contact', 'DocuSign', 'Einstein Activity Capture', 
	    'Email To Salesforce', 'Experience Cloud', 'Experience Cloud Site', 'Financial Services Cloud', 'Force.com', 'Freshdesk', 'GetFeedback Application', 'GitHub', 'GTM',
	    'Hover API', 'Integration Of Sales Cloud With Marketing Cloud', 'Lightning Web Components (LWC)', 'LWC', 'Marketing Cloud', 'Microsoft Azure Database', 'NPSP', 
	    'NPSP Package', 'NSPS', 'Outbound Funds Module', 'Pardot', 'Program management Module' , 'Sales Console', 'Salesforce Appexchange', 'Salesforce B2C Commerce Cloud',
	    'Salesforce Bulk API', 'Salesforce CPQ', 'Salesforce CRM Analytics', 'Salesforce DevOps Center', 'Salesforce Field Service', 'Salesforce Pardot', 'Salesforce Trialforce',
	    'Service Cloud', 'ServiceDesk', 'ShipStation', 'Site Pages', 'Slack', 'Test Sigma', 'Visualforce page', 'Zapier') AND term_id != '1437'";
	}elseif($service == 'Salesforce' && $categoryName == 'Advertising Services'){
	    $product = "name IN ('Sales cloud', 'Service cloud', 'CallRail') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Architecture'){
	    $product = "name IN ('Sales cloud', 'Experience Cloud') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Automobile'){
	    $product = "name IN ('Integration Of Sales Cloud With Marketing Cloud')";   
	}elseif($service == 'Salesforce' && $categoryName == 'Banking'){
	    $product = "name IN ('Sales cloud', 'Salesforce Pardot') AND term_id != '1437'";   
	}elseif(($service == 'Salesforce') && ($categoryName == 'Building And Construction')){
	    $product = "name IN ('Sales cloud', 'Sales Console') AND term_id != '1437'";   
	}elseif(($service == 'Salesforce') && ($categoryName == 'Construction Industry')){
	    $product = "name IN ('Sales cloud', 'Zapier', 'Hover API', 'Salesforce field service', 'Lightning Web Components (LWC)') AND term_id != '1437'";   
	}elseif(($service == 'Salesforce') && ($categoryName == 'Business Consulting And Services')){
	    $product = "name IN ('Sales cloud', 'Experience Cloud Site') AND term_id != '1437'";   
	}elseif(($service == 'Salesforce') && ($categoryName == 'E-Commerce' || $categoryName == 'IT Services And IT Consulting')){
	    $product = "name IN ('Service cloud', 'Sales cloud') AND term_id != '1437'";   
	}elseif(($service == 'Salesforce') && ($categoryName == 'Education' || $categoryName == 'Electric industry' || $categoryName == 'Music Industry' || $category == 'Transportation And Vehicle Rental' || $category == 'Truck Transportation Business')){
	    $product = "name IN ('Sales cloud') AND term_id != '1437'";   
	}elseif(($service == 'Salesforce') && ($categoryName == 'Transportation And Vehicle Rental' || $categoryName == 'Truck Transportation Business')){
	    $product = "name IN ('Sales cloud') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Financial Services'){
	    $product = "name IN ('Sales cloud', 'Microsoft Azure Database', 'Salesforce Bulk API', 'Financial Services Cloud', 'Salesforce CPQ', 'Service Cloud') AND term_id != '1437'";   
	}elseif(($service == 'Salesforce') && ($categoryName == 'General' || $categoryName == 'Healthcare')){
	    $product = "name IN ('Sales cloud', 'Service cloud') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Information Technology & Services'){
	    $product = "name IN ('Sales cloud', 'Service cloud', 'Slack') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Insurance'){
	    $product = "name IN ('Sales cloud', 'Salesforce CRM Analytics') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Non-Profit'){
	    $product = "name IN ('Sales cloud', 'Service cloud', 'Experience Cloud', 'Pardot', 'NPSP Package', 'GitHub', 'Salesforce DevOps Center', 'Constant Contact', 'Test Sigma', 'NPSP', 'DocuSign', 'Marketing Cloud', 'Site Pages', 'Outbound Funds Module', 'Program management Module', 'Einstein Activity Capture') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Professional Services'){
	    $product = "name IN ('Sales cloud', 'Lightning Web Components (LWC)', 'Visualforce page', 'GetFeedback Application', 'Salesforce Appexchange') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Real Estate'){
	    $product = "name IN ('Sales cloud', 'Experience Cloud', 'Salesforce Trialforce', 'Email To Salesforce', 'Einstein Activity Capture', 'Pardot') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Retail Business'){
	    $product = "name IN ('Sales cloud', 'ShipStation', 'Freshdesk') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Retailer'){
	    $product = "name IN ('Sales cloud', 'Freshdesk') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Software Development'){
	    $product = "name IN ('Sales cloud', 'Pardot') AND term_id != '1437'";   
	}elseif($service == 'Salesforce' && $categoryName == 'Telecommunications Industry'){
	    $product = "name IN ('Service cloud')";   
	}elseif($service == 'Salesforce' && $categoryName == 'Translation And Localization'){
	    $product = "name IN ('Sales cloud', 'Force.com', 'Apex Bulk API Integration') AND term_id != '1437'";   
	}
	
	
    
    $wp_table = $table_prefix.'terms';
    $sql = "SELECT term_id, name FROM `$wp_table` WHERE ".$product;
    // $sql = "SELECT term_id, name FROM `$wp_table` WHERE ".$product." Group By name";
    $results = $wpdb->get_results($sql);
    foreach($results as $term){
        echo $response = '<option value="' . $term->term_id . '">' . $term->name . '</option>';
    }
    
    
    exit();
}

/*------------------ Ajax casestudy select box selector on service end ---------------------*/