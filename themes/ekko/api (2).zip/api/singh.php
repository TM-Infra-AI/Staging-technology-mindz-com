<?php  
echo "test";

?>